Step 2:
Rename files using a GUID tool and add an icon for your PBZ
Next, zip these files and rename the zipfile to PBZ.
