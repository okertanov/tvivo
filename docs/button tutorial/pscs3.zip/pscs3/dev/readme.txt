Put a file like this one in Program Files\Picasa2\buttons during development.
