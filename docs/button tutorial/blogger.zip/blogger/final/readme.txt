Step 3:
Detect if Picasa is installed, and if so, present an installbutton link.
